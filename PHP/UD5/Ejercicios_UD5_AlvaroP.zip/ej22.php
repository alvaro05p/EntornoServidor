<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <form action="ej22pantalla.php" method="POST">
        <input type="text" name="email" placeholder="E-mail">
        <input type="text" name="confirmar" placeholder="Confirmar e-mail">
        <div>
            <label for="publi">Deseo recibir publicidad</label>
            <input type="checkbox" name="publi">
        </div>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>